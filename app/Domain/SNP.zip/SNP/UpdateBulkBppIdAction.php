<?php

declare(strict_types=1);

namespace App\Domain\SNP;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class UpdateBulkBppIdAction
{
    public function bulkUpdateMsmeBpp(string $snpCode, array $records): array
    {
        $now = now();

        // Resolve internal SNP ID
        $snpId = $this->getSnpId($snpCode);
        if (!$snpId) {
            return [
                'success' => false,
                'message' => 'Invalid SNP code',
            ];
        }

        // --- 1. Gather statistics from the file ---
        $totalRows = count($records);
        // Count duplicate Udyam numbers (occurrences > 1)
        $udyamCounts = array_count_values(array_column($records, 'udyam_no'));
        $duplicateCount = 0;
        foreach ($udyamCounts as $count) {
            if ($count > 1) {
                $duplicateCount += ($count - 1); // extra occurrences
            }
        }

        // --- 2. Get all MSME IDs for the provided Udyam numbers ---
        $udyamNos = array_unique(array_column($records, 'udyam_no'));
        $msmeMap = DB::table('team_msme_schemes')
            ->whereIn('udyam_no', $udyamNos)
            ->pluck('id', 'udyam_no')
            ->toArray();

        // --- 3. Prepare data for mapping and update ---
        $mappingData = [];
        $msmeIdsToSync = [];
        $updateCase = '';
        $bindings = [];
        $msmeIdsForUpdate = [];

        // We'll store per-row results for the frontend
        $rowResults = [];
        $foundCount = 0;
        $updatedCount = 0;
        $unchangedCount = 0;

        // To avoid duplicate updates for same Udyam in the file, we only process the first occurrence.
        $processedUdyam = [];

        foreach ($records as $record) {
            $udyam = trim($record['udyam_no']);
            $bppId = trim($record['bpp_id']);

            // Determine if this Udyam is duplicate in the file
            $isDuplicate = ($udyamCounts[$udyam] ?? 0) > 1;

            if (!isset($msmeMap[$udyam])) {
                // Udyam not found in DB
                $rowResults[] = [
                    'udyam_no' => $udyam,
                    'bpp_id'   => $bppId,
                    'status'   => 'not_found',
                    'message'  => 'Udyam number not found in database',
                ];
                continue;
            }

            $msmeId = $msmeMap[$udyam];
            $foundCount++;

            // If we've already processed this Udyam (duplicate), skip the update but record the duplicate row
            if (in_array($udyam, $processedUdyam)) {
                $rowResults[] = [
                    'udyam_no' => $udyam,
                    'bpp_id'   => $bppId,
                    'status'   => 'duplicate_skipped',
                    'message'  => 'Duplicate Udyam, only first occurrence processed',
                ];
                continue;
            }

            $processedUdyam[] = $udyam;

            // Get current BPP ID from DB
            $currentBpp = DB::table('team_msme_schemes')
                ->where('id', $msmeId)
                ->value('bpp_id');

            // Prepare mapping data (for team_snpmsme_mapping)
            $mappingData[] = [
                'id'         => (string) Str::uuid(),
                'snp_id'     => $snpId,
                'msme_id'    => $msmeId,
                'status'     => true,
                'created_at' => $now,
                'updated_at' => $now,
            ];

            $msmeIdsToSync[] = $msmeId;

            // Build CASE for BPP update only if the value is different
            if ($currentBpp !== $bppId) {
                $updateCase .= " WHEN ? THEN ? ";
                $bindings[] = $msmeId;
                $bindings[] = $bppId;
                $msmeIdsForUpdate[] = $msmeId;
                $updatedCount++;
                $rowResults[] = [
                    'udyam_no' => $udyam,
                    'bpp_id'   => $bppId,
                    'status'   => 'updated',
                    'message'  => 'BPP ID updated',
                    'old_bpp'  => $currentBpp,
                ];
            } else {
                $unchangedCount++;
                $rowResults[] = [
                    'udyam_no' => $udyam,
                    'bpp_id'   => $bppId,
                    'status'   => 'unchanged',
                    'message'  => 'BPP ID already up-to-date',
                    'old_bpp'  => $currentBpp,
                ];
            }
        }

        // --- 4. Execute the database operations inside a transaction ---
        if (empty($msmeIdsToSync)) {
            return [
                'success' => false,
                'message' => 'No matching MSME records found',
                'stats'   => [
                    'total_rows'   => $totalRows,
                    'duplicates'   => $duplicateCount,
                    'not_found'    => $totalRows - $foundCount - $duplicateCount, // approximate
                    'updated'      => 0,
                    'unchanged'    => 0,
                    'found'        => 0,
                    'details'      => $rowResults,
                ],
            ];
        }

        DB::transaction(function () use ($snpId, $msmeIdsToSync, $mappingData, $updateCase, $bindings, $msmeIdsForUpdate, $now) {
            // Delete existing mappings for these MSMEs under this SNP
            DB::table('team_snpmsme_mapping')
                ->where('snp_id', $snpId)
                ->whereIn('msme_id', $msmeIdsToSync)
                ->delete();

            // Insert new mappings
            DB::table('team_snpmsme_mapping')->insert($mappingData);

            // Bulk update BPP IDs only for those that changed
            if (!empty($msmeIdsForUpdate)) {
                $placeholders = implode(',', array_fill(0, count($msmeIdsForUpdate), '?'));
                $bindings = array_merge($bindings, [$now], $msmeIdsForUpdate);
                $sql = "
                    UPDATE team_msme_schemes
                    SET bpp_id = CASE id
                        {$updateCase}
                    END,
                    bpp_updated_at = ?
                    WHERE id IN ({$placeholders})
                ";
                DB::update($sql, $bindings);
            }
        });

        // --- 5. Return detailed response ---
        return [
            'success'       => true,
            'message'       => 'Bulk BPP ID update completed',
            'stats'         => [
                'total_rows'   => $totalRows,
                'duplicates'   => $duplicateCount, // extra rows with same Udyam
                'not_found'    => $totalRows - $foundCount - $duplicateCount, // those with missing Udyam
                'updated'      => $updatedCount,
                'unchanged'    => $unchangedCount,
                'found'        => $foundCount,
                'details'      => $rowResults,
            ],
            // Optional: redirect URL if you want to keep the redirect
            // 'url' => url('/onboarded-msme'),
        ];
    }

    private function getSnpId(string $snpCode): ?string
    {
        return DB::table('team_snp_scheme')
            ->where('snp_id', $snpCode)
            ->value('id');
    }
}