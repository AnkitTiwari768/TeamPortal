<?php

declare(strict_types=1);

namespace App\Domain\SNP;

use Illuminate\Support\Facades\DB;

class SNPRepository
{
    public function getSnpIdByUserId(string $userId): string
    {
        if (hasRole('lsp') || hasRole('bnp')) {
            return DB::table('users')
            ->select('np.np_team_id')
            ->join('network_providers as np', 'np.user_id', '=', 'users.id')
            ->where('users.id', $userId)
            ->value('np_team_id');
        }
        
        return DB::table('users')
            ->select('team_snp_scheme.snp_id')
            ->join('team_snp_scheme', 'team_snp_scheme.user_id', '=', 'users.id')
            ->where('users.id', $userId)
            ->value('snp_id');
    }
}
