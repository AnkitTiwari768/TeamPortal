<?php

declare(strict_types=1);

namespace App\Domain\SNP;

use Maatwebsite\Excel\Facades\Excel;

class BulkUpdateBppIdData
{
    public static function getRecords($file): array
    {
        $sheets = Excel::toArray([], $file);
        $rows = $sheets[0] ?? [];
        $records = [];

        foreach ($rows as $index => $row) {
            // Skip header row
            if ($index === 0) {
                continue;
            }

            if (empty($row[0]) || empty($row[1])) {
                continue;
            }

            $records[] = [
                'udyam_no' => trim((string) $row[0]),
                'bpp_id'   => trim((string) $row[1]),
            ];
        }
// dd($records);
        return $records;
    }
}