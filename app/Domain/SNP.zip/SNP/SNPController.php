<?php

declare(strict_types=1);

namespace App\Domain\SNP;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

final class SNPController
{
    public function index()
    {
        // Fetch all active SNPs (you may add a 'status' or 'is_active' filter if needed)
        $snps = DB::table('team_snp_scheme')
            ->select('snp_id', 'snp_id')  // adjust column names as per your schema
            ->orderBy('snp_id')
            ->get();

        $title = "BPP ID Mapping";

        return view(
            'snp.bppid_update',
            compact('title', 'snps')
        );
    }

    // public function updateBulkBppId(
    //     Request $request,
    //     UpdateBulkBppIdAction $action
    // ) {
    //     $request->validate([
    //         'file'      => 'required|mimes:xls,xlsx,xlsm',
    //         'snp_code'  => 'required|string|exists:team_snp_scheme,snp_id',
    //     ]);

    //     // Get records from file
    //     $records = BulkUpdateBppIdData::getRecords($request->file('file'));

    //     // Pass the selected SNP code to the action
    //     $result = $action->bulkUpdateMsmeBpp(
    //         $request->input('snp_code'),
    //         $records
    //     );

    //     return response()->json([
    //         'status'  => $result['success'] ?? false,
    //         'message' => $result['message']
    //             ?? 'Bulk BPP ID update successful',
    //         'data'    => $result,
    //     ]);
    // }

    public function updateBulkBppId(Request $request, UpdateBulkBppIdAction $action)
    {
        $request->validate([
            'file'      => 'required|mimes:xls,xlsx,xlsm',
            'snp_code'  => 'required|string|exists:team_snp_scheme,snp_id',
        ]);

        $records = BulkUpdateBppIdData::getRecords($request->file('file'));
        $result = $action->bulkUpdateMsmeBpp(
            $request->input('snp_code'),
            $records
        );

        // Ensure we always return stats even on failure
        return response()->json($result);
    }
}